#pragma once

ref class icon{

private: int x =0, y=0;

public: 
	int get_x();
	int get_y();

	void set_x(int);
	void set_y(int);
	
};